# KOMAND — Prototype MVP

Prototype de démonstration d'une vitrine e-commerce en français, conçu pour évoluer vers une plateforme destinée aux commerçants au Cameroun.

## Fonctionnalités présentes
- Catalogue de démonstration avec recherche
- Ajout de produits de démonstration
- Panier et simulation de commande
- Tableau de bord avec quelques compteurs
- Enregistrement local dans le navigateur (`localStorage`)
- Interface responsive pour téléphone et ordinateur

## Limites importantes
Cette version n'est **pas encore prête pour de vrais vendeurs** :
- pas de comptes utilisateurs ni d'authentification ;
- pas de base de données partagée entre appareils ;
- pas de paiements réels ;
- pas de sécurité serveur ;
- pas de système réel d'essai gratuit de 14 jours ou d'abonnements.
Les commandes et produits sont stockés uniquement dans le navigateur utilisé pour la démonstration. Ne pas y saisir de données personnelles ou bancaires réelles.

## Tester
Ouvrir `index.html` dans un navigateur récent. Pour déployer une simple démonstration statique, le site peut être publié sur un hébergement statique. Le fichier `render.yaml` propose une configuration Render Static Site.

## Prochaine étape de développement
1. Ajouter un backend et une base de données.
2. Ajouter l'authentification des vendeurs.
3. Associer chaque boutique à un compte vendeur.
4. Programmer et tester la période d'essai de 14 jours.
5. Ajouter des abonnements et un fournisseur de paiement compatible avec le Cameroun.
6. Mettre en place validation, sauvegardes, protection contre les abus et tests de sécurité.
