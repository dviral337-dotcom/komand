const initialProducts = [
  {id:1,name:"T-shirt classique",price:5000,category:"Mode",icon:"👕"},
  {id:2,name:"Sac à main",price:8500,category:"Accessoires",icon:"👜"},
  {id:3,name:"Baskets urbaines",price:15000,category:"Chaussures",icon:"👟"},
  {id:4,name:"Montre élégante",price:12000,category:"Accessoires",icon:"⌚"}
];
const read = (key, fallback) => { try { const v=localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } };
let products = read("komand_products", initialProducts);
let cart = read("komand_cart", []);
let orders = read("komand_orders", []);
const money = n => new Intl.NumberFormat("fr-FR").format(n) + " FCFA";
const $ = id => document.getElementById(id);
function save(){localStorage.setItem("komand_products",JSON.stringify(products));localStorage.setItem("komand_cart",JSON.stringify(cart));localStorage.setItem("komand_orders",JSON.stringify(orders));}
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2400);}
function renderProducts(){
 const q=$("search").value.trim().toLowerCase();
 const filtered=products.filter(p=>(p.name+" "+p.category).toLowerCase().includes(q));
 $("product-grid").innerHTML=filtered.length?filtered.map(p=>`<article class="product-card"><div class="product-art">${escapeHTML(p.icon||"📦")}</div><div class="product-info"><span class="product-category">${escapeHTML(p.category||"Divers")}</span><h3>${escapeHTML(p.name)}</h3><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">Ajouter +</button></div></div></article>`).join(""):'<p>Aucun produit trouvé.</p>';
 $("stat-products").textContent=products.length;
 $("stat-orders").textContent=orders.length;
 $("stat-cart").textContent=cart.reduce((s,i)=>s+i.qty,0);
 $("cart-count").textContent=cart.reduce((s,i)=>s+i.qty,0);
}
function renderCart(){
 $("cart-items").innerHTML=cart.length?cart.map(i=>`<div class="cart-item"><div><strong>${escapeHTML(i.name)}</strong><small>${i.qty} × ${money(i.price)}</small></div><div><strong>${money(i.price*i.qty)}</strong><br><button class="remove-button" data-remove="${i.id}">Retirer</button></div></div>`).join(""):'<p>Votre panier est vide.</p>';
 $("cart-total").textContent=money(cart.reduce((s,i)=>s+i.price*i.qty,0));
 $("stat-cart").textContent=cart.reduce((s,i)=>s+i.qty,0);
 $("cart-count").textContent=cart.reduce((s,i)=>s+i.qty,0);
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("product-grid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===Number(b.dataset.add));if(!p)return;const item=cart.find(x=>x.id===p.id);item?item.qty++:cart.push({...p,qty:1});save();renderCart();renderProducts();toast("Produit ajouté au panier.");});
$("cart-items").addEventListener("click",e=>{const b=e.target.closest("[data-remove]");if(!b)return;cart=cart.filter(x=>x.id!==Number(b.dataset.remove));save();renderCart();renderProducts();});
$("search").addEventListener("input",renderProducts);
$("cart-toggle").addEventListener("click",()=>{$("cart-panel").hidden=false;renderCart();});
$("cart-close").addEventListener("click",()=>$("cart-panel").hidden=true);
$("checkout").addEventListener("click",()=>{if(!cart.length){toast("Votre panier est vide.");return;}orders.push({id:Date.now(),items:cart.map(x=>({...x})),total:cart.reduce((s,i)=>s+i.price*i.qty,0),date:new Date().toISOString()});cart=[];save();renderCart();renderProducts();$("cart-panel").hidden=true;toast("Commande de démonstration enregistrée. Aucun paiement réel.");});
$("product-form").addEventListener("submit",e=>{e.preventDefault();const name=$("product-name").value.trim();const price=Number($("product-price").value);if(!name||!Number.isFinite(price)||price<=0){toast("Vérifiez le nom et le prix.");return;}products.unshift({id:Date.now(),name,price,category:$("product-category").value.trim()||"Divers",icon:$("product-icon").value.trim()||"📦"});save();renderProducts();e.target.reset();toast("Produit ajouté au catalogue de démonstration.");});
renderProducts();renderCart();
